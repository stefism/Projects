﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _09_PokemonTrainer
{
    public class Trainer
    {
        public int Badges { get; set; }
        public int Pokemons { get; set; }
    }
}
