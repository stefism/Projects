﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace _01_GenericBoxOfString
{
    public class Box<T>
    {
        private List<T> list;

        public Box()
        {
            list = new List<T>();
        }

        public void Add(T item)
        {
            list.Add(item);
        }

        public override string ToString()
        {
            string output = string.Empty;

            var type = list[0].GetType();

            foreach (var item in list)
            {
               output += $"{type}: {item}{Environment.NewLine}";
            }

            return output;
        }
    }
}
