﻿using System;

namespace _01_GenericBoxOfString
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int numberOfInput = int.Parse(Console.ReadLine());

            Box<string> box = new Box<string>();

            for (int i = 0; i < numberOfInput; i++)
            {
                string input = Console.ReadLine();

                box.Add(input);
            }

            Console.WriteLine(box.ToString());
        }
    }
}
