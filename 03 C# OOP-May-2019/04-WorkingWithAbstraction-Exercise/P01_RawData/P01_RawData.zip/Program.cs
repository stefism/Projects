﻿namespace P01_RawData
{
    public class RawData
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
