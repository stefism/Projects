﻿using System;
using System.Linq;

namespace P03_JediGalaxy
{
    public class Program
    {
        public static void Main()
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}
