﻿using System;
using System.Linq;
using System.Reflection;

namespace CustomRandomList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
