﻿namespace _04_Telephony
{
    public interface IBrowsing
    {
        string Browsing(string webAddress);
    }
}
