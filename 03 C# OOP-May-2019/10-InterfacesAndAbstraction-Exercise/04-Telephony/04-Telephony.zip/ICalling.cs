﻿namespace _04_Telephony
{
    public interface ICalling
    {
        string Calling(string number);
    }
}
