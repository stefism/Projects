﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05_BorderControl
{
    public interface IRobot
    {
        string Model { get; }
    }
}
