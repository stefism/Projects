﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _08_MilitaryElite
{
    public interface ILieutenantGeneral
    {
        List<Private> privates { get; }
    }
}
