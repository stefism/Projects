﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _08_MillitaryElite_Daskal
{
    public enum State
    {
        inProgress,
        Finished
    }
}
