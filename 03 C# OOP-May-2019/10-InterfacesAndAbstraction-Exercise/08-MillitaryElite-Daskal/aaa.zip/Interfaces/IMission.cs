﻿namespace _08_MillitaryElite_Daskal
{
    public interface IMission
    {
        string CodeName { get; }

        State State { get; }

        void CompleteMission();
    }
}
