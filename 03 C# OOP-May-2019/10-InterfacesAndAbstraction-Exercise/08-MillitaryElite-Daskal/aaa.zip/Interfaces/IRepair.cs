﻿namespace _08_MillitaryElite_Daskal
{
    public interface IRepair
    {
        string PartName { get; }
        int HoursWorked { get; }
    }
}
