﻿using System;

namespace _08_MillitaryElite_Daskal
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            // 40 от 100, незнайно защо.

            Engine engine = new Engine();

            engine.Run();
        }
    }
}
