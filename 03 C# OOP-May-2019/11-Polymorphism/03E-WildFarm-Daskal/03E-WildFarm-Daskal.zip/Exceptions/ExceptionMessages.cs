﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03E_WildFarm_Daskal.Exceptions
{
    public static class ExceptionMessages
    {
        public static string InvalidFoodTypeException = 
            "{0} does not eat {1}!";
    }
}
