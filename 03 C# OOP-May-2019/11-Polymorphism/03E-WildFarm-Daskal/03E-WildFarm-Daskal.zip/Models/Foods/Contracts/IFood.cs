﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03E_WildFarm_Daskal.Models.Foods.Contracts
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
