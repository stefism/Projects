﻿using _03E_WildFarm_Daskal.Models.Foods.Contracts;

namespace _03E_WildFarm_Daskal.Models.Foods.Entities
{
    public class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {
        }
    }
}
