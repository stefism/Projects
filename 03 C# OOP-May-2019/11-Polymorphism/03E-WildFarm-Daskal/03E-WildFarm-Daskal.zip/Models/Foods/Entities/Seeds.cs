﻿using _03E_WildFarm_Daskal.Models.Foods.Contracts;

namespace _03E_WildFarm_Daskal.Models.Foods.Entities
{
    public class Seeds : Food
    {
        public Seeds(int quantity) : base(quantity)
        {
        }
    }
}
