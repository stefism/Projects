﻿using _03E_WildFarm_Daskal.Models.Foods.Contracts;

namespace _03E_WildFarm_Daskal.Models.Foods.Entities
{
    public class Vegetable : Food
    {
        public Vegetable(int quantity) : base(quantity)
        {
        }
    }
}
