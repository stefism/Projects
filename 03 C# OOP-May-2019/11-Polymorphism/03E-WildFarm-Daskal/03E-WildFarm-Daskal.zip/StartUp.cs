﻿using _03E_WildFarm_Daskal.Core;
using System;

namespace _03E_WildFarm_Daskal
{
    public class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}
