﻿using System;

namespace _05_CreateAttribute
{
    [Author("Ventsi")]
    public class StartUp
    {
        [Author("Gosho")]
        static void Main(string[] args)
        {
            
        }
    }
}
