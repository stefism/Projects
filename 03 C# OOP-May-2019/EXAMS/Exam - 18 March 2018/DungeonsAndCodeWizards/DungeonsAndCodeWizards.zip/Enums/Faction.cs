﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Enums
{
    public enum Faction
    {
        CSharp,
        Java
    }
}
