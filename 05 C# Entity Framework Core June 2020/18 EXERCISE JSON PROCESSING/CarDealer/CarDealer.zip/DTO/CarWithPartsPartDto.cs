﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.DTO
{
    
    public class CarWithPartsPartDto
    {
       
        public string Name { get; set; }

        
        public decimal Price { get; set; }
    }
}
