﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-LNP1A21\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
