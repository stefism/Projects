﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using SoftJail.Data.Models.Enums;

namespace SoftJail.Data.Models
{
    public class Officer
    {
        public int Id { get; set; }
        //•	Id – integer, Primary Key

        [Required, MaxLength(30)]
        public string FullName { get; set; }
        //•	FullName – text with min length 3 and max length 30 (required)

        [Required, Range(0, Double.MaxValue)]
        public decimal Salary { get; set; }
        //•	Salary – decimal (non-negative, minimum value: 0) (required)

        [Required]
        public Position Position { get; set; }
        //•	Position - Position enumeration with possible values: “Overseer, Guard, Watcher, Labour” (required)

        [Required]
        public Weapon Weapon { get; set; }
        //•	Weapon - Weapon enumeration with possible values: “Knife, FlashPulse, ChainRifle, Pistol, Sniper” (required)

        [Required]
        public int DepartmentId { get; set; }
        //•	DepartmentId - integer, foreign key(required)

        [Required]
        public virtual Department Department { get; set; }
        //•	Department – the officer's department (required)

        public virtual ICollection<OfficerPrisoner> OfficerPrisoners { get; set; } = new HashSet<OfficerPrisoner>();
        //•	OfficerPrisoners - collection of type OfficerPrisoner
    }
}
