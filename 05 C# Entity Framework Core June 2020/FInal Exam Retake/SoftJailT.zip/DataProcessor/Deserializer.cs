﻿using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using Microsoft.EntityFrameworkCore.Internal;
using Newtonsoft.Json;
using SoftJail.Data.Models;
using SoftJail.Data.Models.Enums;
using SoftJail.DataProcessor.ImportDto;

namespace SoftJail.DataProcessor
{

    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using Data;

    public class Deserializer
    {
        public static string ImportDepartmentsCells(SoftJailDbContext context, string jsonString)
        {
            var importedCellsIds = new List<int>();
            var sb = new StringBuilder();

            var departments = JsonConvert.DeserializeObject<ImportDepartmentDto[]>(jsonString);
            foreach (var department in departments)
            {
                var isAnyError = false;

                foreach (var departmentCell in department.Cells)
                {
                    if (!IsValid(departmentCell))
                    {
                        isAnyError = true;
                        break;
                    }
                }

                if (!IsValid(department) || isAnyError)
                {
                    sb.AppendLine("Invalid Data");
                    continue;
                }

                if (!department.Cells.Select(x => importedCellsIds.Contains(x.CellNumber)).Any())
                {
                    sb.AppendLine("Invalid Data");
                    continue;
                }

                var newDepartment = new Department
                {
                    Name = department.Name,
                };
                newDepartment.Cells = GenerateCells(department.Cells, newDepartment);

                context.Departments.Add(newDepartment);
                importedCellsIds.AddRange(department.Cells.Select(x => x.CellNumber).ToList());
                sb.AppendLine($"Imported {department.Name} with {department.Cells.Count} cells");
            }

            context.SaveChanges();
            return sb.ToString();
        }

        public static string ImportPrisonersMails(SoftJailDbContext context, string jsonString)
        {
            var sb = new StringBuilder();

            var prisoners = JsonConvert.DeserializeObject<ImportPrisonerDto[]>(jsonString);
            foreach (var prisoner in prisoners)
            {
                var isAnyError = false;

                foreach (var prisonerMail in prisoner.Mails)
                {
                    if (!IsValid(prisonerMail))
                    {
                        isAnyError = true;
                        break;
                    }
                }

                if (!IsValid(prisoner) || isAnyError)
                {
                    sb.AppendLine("Invalid Data");
                    continue;
                }

                DateTime? releaseDate = null;
                if (prisoner.ReleaseDate != null)
                {
                    releaseDate = DateTime.ParseExact(prisoner.ReleaseDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                var newPrisoner = new Prisoner
                {
                    FullName = prisoner.FullName,
                    Nickname = prisoner.Nickname,
                    Age = prisoner.Age,
                    IncarcerationDate = DateTime.ParseExact(prisoner.IncarcerationDate, "dd/MM/yyyy", CultureInfo.InvariantCulture),
                    ReleaseDate = releaseDate,
                    Bail = prisoner.Bail,
                    CellId = prisoner.CellId
                };
                newPrisoner.Mails = GenerateMails(prisoner.Mails, newPrisoner);

                context.Prisoners.Add(newPrisoner);
                sb.AppendLine($"Imported {prisoner.FullName} {prisoner.Age} years old");
            }


            context.SaveChanges();
            return sb.ToString();
        }

        public static string ImportOfficersPrisoners(SoftJailDbContext context, string xmlString)
        {
            StringBuilder sb = new StringBuilder();

            XmlSerializer xmlSerializer = new XmlSerializer(typeof(ImportOfficerDto[]), new XmlRootAttribute("Officers"));

            ImportOfficerDto[] importedOfficers;
            using (StringReader stringReader = new StringReader(xmlString))
            {
                importedOfficers = (ImportOfficerDto[])xmlSerializer.Deserialize(stringReader);
            }

            foreach (var officer in importedOfficers)
            {
                if (!IsValid(officer))
                {
                    sb.AppendLine("Invalid Data");
                    continue;
                }

                var newOfficer = new Officer
                {
                    FullName = officer.Name,
                    Salary = officer.Money,
                    Position = (Position)Enum.Parse(typeof(Position), officer.Position),
                    Weapon = (Weapon)Enum.Parse(typeof(Weapon), officer.Weapon),
                    DepartmentId = officer.DepartmentId
                };
                newOfficer.OfficerPrisoners = GenerateOfficerPrisoners(officer.OfficerPrisoners, newOfficer);

                context.Officers.Add(newOfficer);
                sb.AppendLine($"Imported {officer.Name} ({officer.OfficerPrisoners.Count} prisoners)");
            }

            context.SaveChanges();
            return sb.ToString();
        }

        private static bool IsValid(object obj)
        {
            var validationContext = new System.ComponentModel.DataAnnotations.ValidationContext(obj);
            var validationResult = new List<ValidationResult>();

            bool isValid = Validator.TryValidateObject(obj, validationContext, validationResult, true);
            return isValid;
        }

        private static ICollection<Cell> GenerateCells(HashSet<ImportCellDto> departmentCells, Department newDepartment)
        {
            var cells = new HashSet<Cell>();
            foreach (var departmentCell in departmentCells)
            {
                cells.Add(new Cell
                {
                    CellNumber = departmentCell.CellNumber,
                    HasWindow = departmentCell.HasWindow,
                    Department = newDepartment
                });
            }

            return cells;
        }

        private static ICollection<Mail> GenerateMails(HashSet<ImportMailDto> prisonerMails, Prisoner prisoner)
        {
            var mails = new HashSet<Mail>();
            foreach (var mail in prisonerMails)
            {
                mails.Add(new Mail
                {
                    Description = mail.Description,
                    Sender = mail.Sender,
                    Address = mail.Address,
                    Prisoner = prisoner
                });
            }

            return mails;
        }

        private static ICollection<OfficerPrisoner> GenerateOfficerPrisoners(HashSet<ImportPrisonerOfficerDto> prisoners, Officer newOfficer)
        {
            var officerPrisoner = new HashSet<OfficerPrisoner>();
            foreach (var prisoner in prisoners)
            {
                officerPrisoner.Add(new OfficerPrisoner
                {
                    PrisonerId = prisoner.Id,
                    Officer = newOfficer
                });
            }

            return officerPrisoner;
        }
    }
}