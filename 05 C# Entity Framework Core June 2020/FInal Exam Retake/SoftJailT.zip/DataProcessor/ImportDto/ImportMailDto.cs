﻿using System.ComponentModel.DataAnnotations;

namespace SoftJail.DataProcessor.ImportDto
{
    public class ImportMailDto
    {
        [Required]
        public string Description { get; set; }
        //•	Description– text(required)

        [Required]
        public string Sender { get; set; }
        //•	Sender – text(required)

        [Required, RegularExpression("[A-Za-z0-9\\s]+ str\\.")]
        public string Address { get; set; }
        //•	Address – text, consisting only of letters, spaces and numbers, which ends with “ str.” (required) (Example: “62 Muir Hill str.“)
    }
}
