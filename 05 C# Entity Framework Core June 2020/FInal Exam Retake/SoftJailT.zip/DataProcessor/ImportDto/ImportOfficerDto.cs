﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Xml.Serialization;
using SoftJail.Data.Models.Enums;

namespace SoftJail.DataProcessor.ImportDto
{
    [XmlType("Officer")]
    public class ImportOfficerDto
    {
        [Required, MinLength(3), MaxLength(30)]
        public string Name { get; set; }
        //•	FullName – text with min length 3 and max length 30 (required)

        [Required, Range(0, Double.MaxValue)]
        public decimal Money { get; set; }
        //•	Salary – decimal (non-negative, minimum value: 0) (required)

        [Required]
        [EnumDataType(typeof(Position))]
        public string Position { get; set; }
        //•	Position - Position enumeration with possible values: “Overseer, Guard, Watcher, Labour” (required)

        [Required]
        [EnumDataType(typeof(Weapon))]
        public string Weapon { get; set; }
        //•	Weapon - Weapon enumeration with possible values: “Knife, FlashPulse, ChainRifle, Pistol, Sniper” (required)

        [Required]
        public int DepartmentId { get; set; }
        //•	DepartmentId - integer, foreign key(required)

        [XmlArray("Prisoners")]
        public virtual HashSet<ImportPrisonerOfficerDto> OfficerPrisoners { get; set; } = new HashSet<ImportPrisonerOfficerDto>();
        //•	OfficerPrisoners - collection of type OfficerPrisoner
    }
}
