﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SoftJail.DataProcessor.ImportDto
{
    public class ImportPrisonerDto
    {
        [Required, MinLength(3), MaxLength(20)]
        public string FullName { get; set; }
        //•	FullName – text with min length 3 and max length 20 (required)

        [Required, RegularExpression("The [A-Z][a-z]+")]
        public string Nickname { get; set; }
        //•	Nickname – text starting with "The " and a single word only of letters with an uppercase letter for beginning(example: The Prisoner) (required)

        [Required, Range(18, 65)]
        public int Age { get; set; }
        //•	Age – integer in the range[18, 65] (required)

        [Required]
        [DataType(DataType.DateTime)]
        public string IncarcerationDate { get; set; }
        //•	IncarcerationDate ¬– Date(required)

        [DataType(DataType.DateTime)]
        public string ReleaseDate { get; set; }
        //•	ReleaseDate– Date

        [Range(0, Double.MaxValue)]
        public decimal? Bail { get; set; }
        //•	Bail– decimal (non-negative, minimum value: 0)

        public int? CellId { get; set; }
        //•	CellId - integer, foreign key

        public virtual HashSet<ImportMailDto> Mails { get; set; } = new HashSet<ImportMailDto>();
        //•	Mails - collection of type Mail
    }
}
