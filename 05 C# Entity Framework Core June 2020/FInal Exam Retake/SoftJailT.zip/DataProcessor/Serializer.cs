﻿using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using Newtonsoft.Json;
using SoftJail.DataProcessor.ExportDto;

namespace SoftJail.DataProcessor
{

    using System;
    using Data;

    public class Serializer
    {
        public static string ExportPrisonersByCells(SoftJailDbContext context, int[] ids)
        {
            var prisoners = context.Prisoners
                                        .ToArray()
                                        .Where(x => ids.Contains(x.Id))
                                        .Select(p => new
                                        {
                                            Id = p.Id,
                                            Name = p.FullName,
                                            CellNumber = p.Cell.CellNumber,
                                            Officers = p.PrisonerOfficers.Select(o => new
                                            {
                                                OfficerName = o.Officer.FullName,
                                                Department = o.Officer.Department.Name
                                            })
                                                .OrderBy(x => x.OfficerName)
                                                .ToArray(),
                                            TotalOfficerSalary = p.PrisonerOfficers.Select(x => x.Officer.Salary).Sum()
                                        })
                                        .OrderBy(x => x.Name)
                                        .ThenBy(x => x.Id)
                                        .ToArray();


            string json = JsonConvert.SerializeObject(prisoners, Formatting.Indented);

            return json;
        }

        public static string ExportPrisonersInbox(SoftJailDbContext context, string prisonersNames)
        {
            StringBuilder sb = new StringBuilder();
            var prisonersNamesSplited = prisonersNames.Split(",");

            XmlSerializer xmlSerializer = new XmlSerializer(typeof(ExportPrisonerDto[]), new XmlRootAttribute("Prisoners"));
            XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
            namespaces.Add(string.Empty, string.Empty);

            using (StringWriter stringWriter = new StringWriter(sb))
            {
                var prisoners = context.Prisoners
                                        .ToArray()
                                        .Where(x => prisonersNamesSplited.Contains(x.FullName))
                                        .Select(p => new ExportPrisonerDto
                                        {
                                            Id = p.Id,
                                            Name = p.FullName,
                                            IncarcerationDate = p.IncarcerationDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
                                            Mails = p.Mails.Select(m => new ExportMessageDto
                                            {
                                                Description = Reverse(m.Description)
                                            })
                                                .ToHashSet()
                                        })
                                        .OrderBy(x => x.Name)
                                        .ThenBy(x => x.Id)
                                        .ToArray();

                xmlSerializer.Serialize(stringWriter, prisoners, namespaces);
            }

            return sb.ToString().TrimEnd();
        }

        private static string Reverse(string stringToReverse)
        {
            char[] stringArray = stringToReverse.ToCharArray();
            string reverse = string.Empty;
            for (int i = stringArray.Length - 1; i >= 0; i--)
            {
                reverse += stringArray[i];
            }

            return reverse;
        }
    }
}