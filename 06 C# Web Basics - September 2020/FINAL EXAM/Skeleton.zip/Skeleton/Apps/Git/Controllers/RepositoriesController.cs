﻿using System;
using Git.Services;
using SUS.HTTP;
using SUS.MvcFramework;

namespace Git.Controllers
{
    public class RepositoriesController : Controller
    {
        private readonly IRepositoryService repositoryService;

        public RepositoriesController(IRepositoryService repositoryService)
        {
            this.repositoryService = repositoryService;
        }

        public HttpResponse Create()
        {
            if (!this.IsUserSignedIn())
            {
                return this.Redirect("/Users/Login");
            }

            return this.View();
        }

        [HttpPost]
        public HttpResponse Create(string name, string repositoryType)
        {
            if (!this.IsUserSignedIn())
            {
                return this.Redirect("/Users/Login");
            }

            if (string.IsNullOrEmpty(name) || name.Length < 3 || name.Length > 10)
            {
                return this.Error("Name should be between 5 and 10 characters.");
            }

            if (string.IsNullOrEmpty(repositoryType) ||
                !repositoryType.Equals("Public", StringComparison.OrdinalIgnoreCase) &&
                !repositoryType.Equals("Private", StringComparison.OrdinalIgnoreCase))
            {
                return this.Error("Type should be Public or Private!");
            }

            var userId = this.GetUserId();
            this.repositoryService.Create(name, repositoryType, userId);
            return this.Redirect("/Repositories/All");
        }

        public HttpResponse All()
        {
            var userId = this.GetUserId();
            var viewModel = repositoryService.GetAll(userId);
            return this.View(viewModel);
        }
    }
}
