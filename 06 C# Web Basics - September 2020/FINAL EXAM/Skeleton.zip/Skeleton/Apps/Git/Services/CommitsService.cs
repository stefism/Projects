﻿using System;
using System.Collections.Generic;
using System.Linq;
using Git.Data;
using Git.Data.Models;
using Git.ViewModels.Commits;

namespace Git.Services
{
    public class CommitsService : ICommitsService
    {
        private readonly ApplicationDbContext db;

        public CommitsService(ApplicationDbContext db)
        {
            this.db = db;
        }

        public string GetNameById(string id)
        {
            return this.db.Repositories
                .Where(x => x.Id == id)
                .Select(x => x.Name)
                .FirstOrDefault();
        }

        public void Create(string id, string userId, string description)
        {
            var commit = new Commit
            {
                Description = description,
                CreatedOn = DateTime.UtcNow,
                RepositoryId = id,
                CreatorId = userId
            };

            db.Commits.Add(commit);
            db.SaveChanges();
        }

        public IEnumerable<CommitViewModel> GetAllById(string userId)
        {
            return this.db.Commits
                .Where(x => x.CreatorId == userId)
                .Select(x => new CommitViewModel
                {
                    Id = x.Id,
                    Repository = x.Repository.Name,
                    Description = x.Description,
                    CreatedOn = x.CreatedOn.ToString("yyyy-MM-dd HH:mm")
                }).ToList();
        }

        public bool CheckIfCommitExits(string id, string userId)
        {
            return this.db.Commits.FirstOrDefault(x => x.Id == id && x.CreatorId == userId) != null;
        }

        public void Delete(string id)
        {
            var commit = this.db.Commits.Find(id);
            this.db.Commits.Remove(commit);
            this.db.SaveChanges();
        }
    }
}
