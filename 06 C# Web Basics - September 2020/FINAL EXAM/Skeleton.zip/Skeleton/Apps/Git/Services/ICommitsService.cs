﻿using System.Collections.Generic;
using Git.ViewModels.Commits;

namespace Git.Services
{
    public interface ICommitsService
    {
        string GetNameById(string id);
        void Create(string id, string userId, string description);
        IEnumerable<CommitViewModel> GetAllById(string userId);
        bool CheckIfCommitExits(string id, string userId);
        void Delete(string id);
    }
}
