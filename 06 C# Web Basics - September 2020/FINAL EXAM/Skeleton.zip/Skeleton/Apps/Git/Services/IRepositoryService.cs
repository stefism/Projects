﻿using System.Collections.Generic;
using Git.ViewModels.Repositories;

namespace Git.Services
{
    public interface IRepositoryService
    {
        void Create(string name, string repositoryType, string userId);

        IEnumerable<RepositoryViewModel> GetAll(string userId);
    }
}
