﻿using System;
using System.Collections.Generic;
using System.Linq;
using Git.Data;
using Git.Data.Models;
using Git.ViewModels.Repositories;

namespace Git.Services
{
    public class RepositoryService : IRepositoryService
    {
        private readonly ApplicationDbContext db;

        public RepositoryService(ApplicationDbContext db)
        {
            this.db = db;
        }

        public void Create(string name, string repositoryType, string userId)
        {
            var repository = new Repository
            {
                Name = name,
                CreatedOn = DateTime.UtcNow,
                OwnerId = userId,
                IsPublic = repositoryType.Equals("Public")
            };

            this.db.Repositories.Add(repository);
            db.SaveChanges();
        }

        public IEnumerable<RepositoryViewModel> GetAll(string userId)
        {
            return db.Repositories
                .Where(x => x.IsPublic || (!x.IsPublic && x.OwnerId == userId))
                .Select(x => new RepositoryViewModel
                {
                    Id = x.Id,
                    Name = x.Name,
                    CreatedOn = x.CreatedOn.ToString("dd/MM/yyyy HH:mm"),
                    Owner = x.Owner.Username,
                    Commits = x.Commits.Count
                }).ToList();
        }
    }
}
