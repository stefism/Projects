﻿namespace Git.ViewModels.Commits
{
    public class CreateCommitViewModel
    {
        public string Name { get; set; }

        public string Id { get; set; }
    }
}
