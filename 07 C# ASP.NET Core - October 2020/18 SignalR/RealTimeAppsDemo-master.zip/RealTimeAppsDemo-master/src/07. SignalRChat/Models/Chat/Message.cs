﻿namespace SignalRChat.Models.Chat
{
    public class Message
    {
        public string User { get; set; }

        public string Text { get; set; }
    }
}
