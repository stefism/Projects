﻿namespace MusicHub.DataProcessor
{
    using System;

    using Data;

    public class Serializer
    {
        public static string ExportAlbumsInfo(MusicHubDbContext context, int producerId)
        {
            return "";
        }

        public static string ExportSongsAboveDuration(MusicHubDbContext context, int duration)
        {
            return "";
        }
    }
}