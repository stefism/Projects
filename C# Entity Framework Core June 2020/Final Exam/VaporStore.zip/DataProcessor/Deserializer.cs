﻿using System.Globalization;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using VaporStore.Data.Models;
using VaporStore.DataProcessor.Dto.Import;

namespace VaporStore.DataProcessor
{
	using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using Data;

	public static class Deserializer
	{
		public static string ImportGames(VaporStoreDbContext context, string jsonString)
		{
			var sb = new StringBuilder();
            var games = JsonConvert.DeserializeObject<GameImportDto[]>(jsonString);

            foreach (var game in games)
            {

                if (!IsValid(game))
                {
                    sb.AppendLine("Invalid Data");
					continue;

                }

                var developer = context.Developers.FirstOrDefault(x => x.Name == game.Developer) ?? new Developer
                {
                    Name = game.Developer
                };

                var genre = context.Genres.FirstOrDefault(x => x.Name == game.Genre) ?? new Genre
                {
                    Name = game.Genre
                };

                var newgame = new Game
                {
                    Name = game.Name,
                    Price = game.Price,
                    ReleaseDate = DateTime.ParseExact(game.ReleaseDate, "yyyy-MM-dd", CultureInfo.InvariantCulture),
                    Developer = developer,
                    Genre = genre
                };

                newgame.GameTags = GenerateGameTags(game, newgame, context);

                sb.AppendLine($"Added {newgame.Name} ({newgame.Genre.Name}) with {newgame.GameTags.Count} tags");
				context.Games.Add(newgame);
                context.SaveChanges();
            }

            return sb.ToString();
        }

        private static ICollection<GameTag> GenerateGameTags(GameImportDto gameDto, Game newGame, VaporStoreDbContext context)
        {
            var newGameTags = new HashSet<GameTag>();
            foreach (var tagName in gameDto.Tags)
            {
                var tag = context.Tags.FirstOrDefault(x => x.Name == tagName) ?? new Tag
                {
                    Name = tagName
                };

                newGameTags.Add(new GameTag
                {
                    Game = newGame,
                    Tag = tag
                });
            }

            return newGameTags;
        }

        public static string ImportUsers(VaporStoreDbContext context, string jsonString)
		{
			throw new NotImplementedException();
		}

		public static string ImportPurchases(VaporStoreDbContext context, string xmlString)
		{
			throw new NotImplementedException();
		}

		private static bool IsValid(object dto)
		{
			var validationContext = new ValidationContext(dto);
			var validationResult = new List<ValidationResult>();

			return Validator.TryValidateObject(dto, validationContext, validationResult, true);
		}
	}
}