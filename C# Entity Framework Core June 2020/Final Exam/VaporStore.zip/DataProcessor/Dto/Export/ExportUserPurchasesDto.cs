﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace VaporStore.DataProcessor.Dto.Export
{
    [XmlType("User")]
    public class ExportUserPurchasesDto
    {
        [XmlAttribute("username")]
        public string Username { get; set; }

        [XmlArray("Purchases")]
        public HashSet<PurchaseExportDto> Purchases { get; set; } = new HashSet<PurchaseExportDto>();

        public string TotalSpent { get; set; }
    }
}
