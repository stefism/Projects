﻿using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Newtonsoft.Json;
using VaporStore.DataProcessor.Dto.Export;
using Formatting = Newtonsoft.Json.Formatting;

namespace VaporStore.DataProcessor
{
    using System;
    using Data;

    public static class Serializer
    {
        public static string ExportGamesByGenres(VaporStoreDbContext context, string[] genreNames)
        {
            var genres = context.Genres.Where(x => genreNames.Contains(x.Name))
                .ToArray()
                .Select(x => new
                {
                    Id = x.Id,
                    Genre = x.Name,
                    Games = x.Games.Where(y => y.Purchases.Any()).Select(g => new
                    {
                        Id = g.Id,
                        Title = g.Name,
                        Developer = g.Developer.Name,
                        Tags = string.Join(", ", g.GameTags.Select(t => t.Tag.Name)),
                        Players = g.Purchases.Count
                    })
                      .OrderByDescending(y => y.Players)
                      .ThenBy(y => y.Id)
                      .ToArray(),
                    TotalPlayers = x.Games.Select(y => y.Purchases.Count).Sum()
                })
                .OrderByDescending(x => x.TotalPlayers)
                .ThenBy(x => x.Id)
                .ToArray();

            var jsonString = JsonConvert.SerializeObject(genres, Formatting.Indented);

            return jsonString;

        }

        public static string ExportUserPurchasesByType(VaporStoreDbContext context, string storeType)
        {
            var users = context.Users.
                Where(x => x.Cards.Select(y => y.Purchases.Any(q => q.Type.ToString() == storeType)).Any())
                .ToArray()
                .Select(x => new ExportUserPurchasesDto
                {
                    Username = x.Username,
                    Purchases = x.Cards.SelectMany(y => y.Purchases).Where(y => y.Type.ToString() == storeType)
                        .Select(y => new PurchaseExportDto
                        {
                            Card = y.Card.Number,
                            Cvc = y.Card.Cvc,
                            Date = y.Date.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture),
                            Game = new GameExportDto
                            {
                                Title = y.Game.Name,
                                Genre = y.Game.Genre.Name,
                                Price = $"{y.Game.Price:F2}"
                            }
                        })
                        .OrderBy(y => y.Date)
                        .ToHashSet(),
                    TotalSpent = $"{x.Cards.SelectMany(y => y.Purchases.Where(z => z.Type.ToString() == storeType).Select(z => z.Game.Price)).Sum():F2}"
                })
                .OrderByDescending(x => x.TotalSpent)
                .ThenBy(x => x.Username)
                .ToArray();

            var xmlSerializer = new XmlSerializer(typeof(ExportUserPurchasesDto[]), new XmlRootAttribute("Users"));

            var sb = new StringBuilder();
            var namespaces = new XmlSerializerNamespaces(new[] { XmlQualifiedName.Empty });
            xmlSerializer.Serialize(new StringWriter(sb), users, namespaces);

            return sb.ToString().TrimEnd();
        }
    }
}