﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
			@"Server=DESKTOP-LNP1A21\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
	}
}

