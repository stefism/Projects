﻿namespace VaporStore.DataProcessor
{
	using System;
    using System.Collections.Generic;
    using System.Linq;
    using Data;
    using VaporStore.Data.Models;

    public static class Serializer
	{
		public static string ExportGamesByGenres(VaporStoreDbContext context, string[] genreNames)
		{
			var genres = new List<Genre>();
			//var games = new List<Game>();

            foreach (var genre in genreNames)
            {
				var genr = context.Genres.FirstOrDefault(g => g.Name == genre);

				genres.Add(genr);
				//var game = context.Games.FirstOrDefault(g => g.Genre.Name == genre);
				
				//games.Add(game);
            }

			//var output = genres.Where(g => g.Games.)

			return "123";
		}

		public static string ExportUserPurchasesByType(VaporStoreDbContext context, string storeType)
		{
			return "123";
		}
	}
}