﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data
{
    static class Configuration
    {
        internal const string DefaultConnection =
            @"Server=DESKTOP-LNP1A21\SQLEXPRESS;
                Database=SalesDatabase;
                Integrated Security=True;";
    }
}
