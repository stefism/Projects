﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => @"Server=STEFCHO\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
