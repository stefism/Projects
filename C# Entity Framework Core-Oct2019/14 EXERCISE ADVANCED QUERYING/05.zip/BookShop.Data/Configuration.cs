﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => 
            @"Server=DESKTOP-LNP1A21\SQLEXPRESS;
                Database=BookShop;
                Integrated Security=True;";
    }
}
