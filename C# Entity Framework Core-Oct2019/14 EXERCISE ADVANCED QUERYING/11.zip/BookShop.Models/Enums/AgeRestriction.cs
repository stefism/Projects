﻿namespace BookShop.Models.Enums
{
    public enum AgeRestriction
    {
        None = -1,
        Minor = 0,
        Teen = 1,
        Adult = 2
    }
}
