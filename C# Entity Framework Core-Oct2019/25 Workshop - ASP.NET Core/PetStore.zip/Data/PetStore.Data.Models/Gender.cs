﻿namespace PetStore.Data.Models
{
    public enum Gender
    {
        Male = 0,
        Female = 1
    }
}
