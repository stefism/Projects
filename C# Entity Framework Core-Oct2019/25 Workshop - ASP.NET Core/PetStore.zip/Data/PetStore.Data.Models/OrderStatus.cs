﻿namespace PetStore.Data.Models
{
    public enum OrderStatus
    {
        Paid = 0,
        Pending = 1,
        Done = 2
    }
}
