﻿namespace PetStore.Data
{
    public class DataSettings
    {
        public const string Connection = @"Server=DESKTOP-GJ7U07L\SQLEXPRESS;Database=PetStoreCatalog;Integrated Security=True;";
    }
}
