﻿namespace PetStore.Services.Models.Brand
{
    public class BrandListingServiceModel
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
