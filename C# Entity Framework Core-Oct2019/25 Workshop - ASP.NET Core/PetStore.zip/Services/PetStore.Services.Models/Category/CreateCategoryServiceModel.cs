﻿namespace PetStore.Services.Models.Category
{
    public class CreateCategoryServiceModel
    {
        public string Name { get; set; }

        public string Description { get; set; }
    }
}
