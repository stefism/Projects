﻿namespace PetStore.Services.Models.Category
{
    public class EditCategoryServiceModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }
    }
}
