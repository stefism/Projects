﻿namespace PetStore.Services
{
    public interface IOrderService
    {
        void CompleteOrder(int orderId);
    }
}
