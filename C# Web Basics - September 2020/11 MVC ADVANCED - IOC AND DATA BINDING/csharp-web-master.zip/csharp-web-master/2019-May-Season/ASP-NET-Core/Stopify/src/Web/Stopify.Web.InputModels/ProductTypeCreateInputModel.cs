﻿namespace Stopify.Web.InputModels
{
    public class ProductTypeCreateInputModel
    {
        public string Name { get; set; }
    }
}
