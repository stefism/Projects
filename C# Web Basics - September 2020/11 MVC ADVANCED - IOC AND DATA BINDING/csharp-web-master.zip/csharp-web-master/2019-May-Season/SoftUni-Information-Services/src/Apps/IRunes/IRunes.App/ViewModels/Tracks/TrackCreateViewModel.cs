﻿namespace IRunes.App.ViewModels.Tracks
{
    public class TrackCreateViewModel
    {
        public string AlbumId { get; set; }
    }
}
