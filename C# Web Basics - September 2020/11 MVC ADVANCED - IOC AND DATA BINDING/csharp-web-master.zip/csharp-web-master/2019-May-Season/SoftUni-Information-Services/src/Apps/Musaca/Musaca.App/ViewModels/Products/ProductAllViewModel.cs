﻿namespace Musaca.App.ViewModels.Products
{
    public class ProductAllViewModel
    {
        public string Name { get; set; }

        public decimal Price { get; set; }
    }
}
