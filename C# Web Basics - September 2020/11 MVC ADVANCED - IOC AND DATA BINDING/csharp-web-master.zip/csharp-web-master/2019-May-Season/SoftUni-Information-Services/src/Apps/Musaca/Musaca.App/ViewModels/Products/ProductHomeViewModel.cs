﻿namespace Musaca.App.ViewModels.Products
{
    public class ProductHomeViewModel
    {
        public string Name { get; set; }

        public decimal Price { get; set; }
    }
}
