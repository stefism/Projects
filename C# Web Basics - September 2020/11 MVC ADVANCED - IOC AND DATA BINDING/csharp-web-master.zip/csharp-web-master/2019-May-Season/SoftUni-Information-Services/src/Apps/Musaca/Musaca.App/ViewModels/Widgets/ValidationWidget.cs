﻿namespace Musaca.App.ViewModels.Widgets
{
    using SIS.MvcFramework.ViewEngine;

    public class ValidationWidget : ViewWidget
    {
    }
}
