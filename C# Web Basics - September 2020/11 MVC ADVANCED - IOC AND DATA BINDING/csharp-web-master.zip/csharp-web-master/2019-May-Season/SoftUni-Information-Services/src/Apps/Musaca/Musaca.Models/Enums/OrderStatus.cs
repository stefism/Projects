﻿namespace Musaca.Models.Enums
{
    public enum OrderStatus
    {
        Active,
        Completed
    }
}
