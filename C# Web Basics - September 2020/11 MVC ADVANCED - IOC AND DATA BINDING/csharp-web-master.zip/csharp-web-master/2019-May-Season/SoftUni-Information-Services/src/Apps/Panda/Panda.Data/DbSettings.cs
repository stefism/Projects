﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Panda.Data
{
    public static class DbSettings
    {
        public const string ConnectionString = @"Integrated Security=True;Server=.;Database=Panda";
    }
}
