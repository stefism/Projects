﻿namespace Panda.Data.Models
{
    public enum PackageStatus
    {
        Pending = 1,
        Delivered = 2,
    }
}
