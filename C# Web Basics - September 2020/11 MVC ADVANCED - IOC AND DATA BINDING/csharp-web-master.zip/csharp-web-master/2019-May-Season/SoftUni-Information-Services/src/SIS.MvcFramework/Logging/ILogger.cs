﻿namespace SIS.MvcFramework.Logging
{
    public interface ILogger
    {
        void Log(string message);
    }
}
