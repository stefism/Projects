﻿namespace ForumSystem.Common
{
    public static class GlobalConstants
    {
        public const string SystemName = "ForumSystem";

        public const string AdministratorRoleName = "Administrator";
    }
}
