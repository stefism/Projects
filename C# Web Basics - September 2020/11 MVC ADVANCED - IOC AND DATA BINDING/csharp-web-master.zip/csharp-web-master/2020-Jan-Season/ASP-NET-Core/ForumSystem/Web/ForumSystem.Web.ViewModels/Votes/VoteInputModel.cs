﻿namespace ForumSystem.Web.ViewModels.Votes
{
    public class VoteInputModel
    {
        public int PostId { get; set; }

        public bool IsUpVote { get; set; }
    }
}
