﻿using _02_CarExtension;
using System;

namespace CarManufacturer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Car car = new Car();
            car.FuelQuantity = 200;
            car.FuelConsumption = 1;
            car.Drive(20);
            Console.WriteLine(car.WhoAmI());
        }
    }
}
