﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04_HotelReservation
{
    public enum Discount
    {
        Vip = 20,
        SecondVisit = 10
    }
}
