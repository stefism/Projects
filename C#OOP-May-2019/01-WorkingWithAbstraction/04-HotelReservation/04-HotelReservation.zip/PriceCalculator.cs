﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04_HotelReservation
{
    public class PriceCalculator
    {
        public static double GetTotalPrice(double pricePerDay, 
            int numberOfDays, string season, string discount = "")
        {
            double totalPrice = 0;

            if (season == "Spring")
            {
                totalPrice = (pricePerDay * numberOfDays) * (double)Season.Spring;
            }

            else if (season == "Winter")
            {
                totalPrice = (pricePerDay * numberOfDays) * (double)Season.Winter;
            }

            else if (season == "Summer")
            {
                totalPrice = (pricePerDay * numberOfDays) * (double)Season.Summer;
            }

            else if (season == "Autumn")
            {
                totalPrice = (pricePerDay * numberOfDays);
            }

            if (discount == "VIP")
            {
                double vipDiscount = totalPrice * (double)Discount.Vip / 100;
                totalPrice -= vipDiscount;
            }

            else if (discount == "SecondVisit")
            {
                double secondDiscount = totalPrice * (double)Discount.SecondVisit / 100;
                totalPrice -= secondDiscount;
            }

            return totalPrice;
        }
    }
}
