﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04_HotelReservation
{
    public enum Season
    {
        Autumn = 1,
        Spring,
        Winter,
        Summer
    }
}

