﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _02_PointInRectangle
{
    public class Rectangle
    {
        public Rectangle(int topLeftX, int topLeftY, int bottomRightX, int bottomRightY)
        {
            TopLeftX = topLeftX;
            TopLeftY = topLeftY;
            BottomRightX = bottomRightX;
            BottomRightY = bottomRightY;
        }

        public int TopLeftX { get; set; }
        public int TopLeftY { get; set; }
        public int BottomRightX { get; set; }
        public int BottomRightY { get; set; }

        public bool Contains(Point point)
        {
            if (point.X >= TopLeftX && point.X <= BottomRightX 
                && point.Y >= TopLeftY && point.Y <= BottomRightY)
            {
                return true;
            }

            return false;
        }
    }
}
