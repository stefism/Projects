﻿using _05_FootballTeam_Daskal.Core;
using System;

namespace _05_FootballTeam_Daskal
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}
