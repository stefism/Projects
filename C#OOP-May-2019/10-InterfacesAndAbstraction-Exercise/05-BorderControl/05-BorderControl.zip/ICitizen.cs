﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05_BorderControl
{
    public interface ICitizen
    {
        string Name { get; }
        int Age { get; }
        string Id { get; }
    }
}
