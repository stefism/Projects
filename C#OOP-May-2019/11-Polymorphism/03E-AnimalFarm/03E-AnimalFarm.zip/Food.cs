﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03E_AnimalFarm
{
    public abstract class Food
    {
        int Quantity { get; }
    }
}
