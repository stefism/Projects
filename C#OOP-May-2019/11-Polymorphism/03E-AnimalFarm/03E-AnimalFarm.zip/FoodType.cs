﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03E_AnimalFarm
{
    public enum FoodType
    {
        Vegetable = 1,
        Fruit,
        Meat,
        Seeds
    }
}
