﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViceCity.Models.Players
{
    public class MainPlayer : Player
    {
        public MainPlayer() : base("Tommy Vercetti", 100)
        {
            ;;
        }
    }
}
