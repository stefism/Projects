﻿namespace ViceCity.Core.Contracts
{
    internal interface IEngine
    {
        void Run();
    }
}