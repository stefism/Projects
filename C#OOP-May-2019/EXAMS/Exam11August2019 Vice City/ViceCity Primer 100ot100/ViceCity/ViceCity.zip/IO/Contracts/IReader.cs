﻿namespace ViceCity.IO.Contracts
{
    internal interface IReader
    {
        string ReadLine();
    }
}