﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MortalEngines.IO.Contracts
{
    public class Reader : IReader
    {
        public IList<ICommand> ReadCommands()
        {
            throw new NotImplementedException();
        }
    }
}
