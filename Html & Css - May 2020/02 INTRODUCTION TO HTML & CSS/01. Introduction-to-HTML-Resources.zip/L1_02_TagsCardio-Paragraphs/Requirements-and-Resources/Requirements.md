﻿# 02 - Tags Cardio - Paragraphs
------

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1136/Introduction-to-HTML-and-CSS).
## Constraints
* Change the document **title** to *Paragraphs*
* Use the **h1** tag for heading
* Use **p** tags for each line of the text
* See the screenshot and use **strong** and **em** tags where needed