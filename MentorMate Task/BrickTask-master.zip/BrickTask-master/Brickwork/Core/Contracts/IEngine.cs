﻿namespace Brickwork.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
