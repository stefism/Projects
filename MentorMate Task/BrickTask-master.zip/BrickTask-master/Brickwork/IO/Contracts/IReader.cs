﻿namespace Brickwork.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
