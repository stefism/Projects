import React from "react";

class Application extends React.Component {
    constructor(){
        super();
        this.state = {
            firstName: "",
            lastName: "",
            age: "",
            gender: "",
            destination: "",
            dietaryRestrictions: {
                isVegan: false,
                isKosher: false,
                isLacroseFree: false
            }
        }
        this.handleChange = this.handleChange.bind(this)
    }

    handleChange(event){
        let {name, value} = event.target
        this.setState({
            [name]: value
        })
    }

    render(){
        return(
            <main>
                <form>                    
                    <input 
                        name="firstName" 
                        value={this.state.firstName}
                        onChange={this.handleChange}
                        placeholder="First Name" /> <br/>

                    <input 
                        name="lastName" 
                        value={this.state.lastName}
                        onChange={this.handleChange}
                        placeholder="Last Name" /> <br/>

                    <input 
                        name="age" 
                        value={this.state.age} 
                        onChange={this.handleChange}
                        placeholder="Age" /> <br/>

                    <label>
                        <input type="radio" name="gender" value="male"
                        checked={this.state.gender === "male"}
                        onChange={this.handleChange}/> Male
                    </label>

                    <label>
                        <input type="radio" name="gender" value="female"
                        checked={this.state.gender === "female"}
                        onChange={this.handleChange}/> Female
                    </label>
                    <br />
                    <select 
                        value={this.state.destination}
                        name="destination"
                        onChange={this.handleChange}
                        >
                        
                        <option value="">Choose a destination</option>
                        <option value="germany">Germany</option>
                        <option value="france">France</option>
                        <option value="spain">Spain</option>
                        <option value="portugal">Portugal</option>
                    </select>
                    <br/>

                    <label>
                        <input 
                        type="checkbox" 
                        name="isVegan"
                        onChange={this.handleChange}
                        checked={this.state.dietaryRestrictions.isVegan}
                        /> Vegan?
                    </label>

                    <label>
                        <input 
                        type="checkbox" 
                        name="isKosher"
                        onChange={this.handleChange}
                        checked={this.state.dietaryRestrictions.isKosher}
                        /> Kosher?
                    </label>

                    <label>
                        <input 
                        type="checkbox" 
                        name="isLacroseFree"
                        onChange={this.handleChange}
                        checked={this.state.dietaryRestrictions.isLacroseFree}
                        /> Lactose?
                    </label>

                    <br/>
                    <button>Submit</button>
                </form>
                <hr/>
                <h2>Entered information:</h2>
                <p>Your name: {this.state.firstName} {this.state.lastName}</p>
                <p>Your age: {this.state.age}</p>
                <p>Your gender: {this.state.gender}</p>
                <p>Your destination: {this.state.destination}</p>
                <p>
                    Your dietary restrictions:
                    {this.state.dietaryRestrictions}
                </p>
            </main>
        )
    }
}

export default Application