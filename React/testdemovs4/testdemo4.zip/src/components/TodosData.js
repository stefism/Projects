let todosData = [
    {
        id: 1,
        text: "1- Todos task 1",
        completed: true
    },
    {
        id: 2,
        text: "2- Todos task 2",
        completed: false
    },
    {
        id: 3,
        text: "3- Todos task 3",
        completed: false
    },
    {
        id: 4,
        text: "4- Todos task 4",
        completed: true
    },
    {
        id: 5,
        text: "5- Todos task 5",
        completed: false
    },
]

export default todosData